type Bus = {
  ctx: AudioContext;
  master: GainNode;
  sfx: GainNode;
};

let bus: Bus | null = null;

function getBus(): Bus | null {
  if (typeof window === "undefined") return null;
  if (bus) return bus;
  const Ctx = window.AudioContext || (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return null;
  const ctx = new Ctx({ latencyHint: "interactive" });
  const master = ctx.createGain();
  const sfx = ctx.createGain();
  master.gain.value = 0.7;
  sfx.gain.value = 0.85;
  sfx.connect(master);
  master.connect(ctx.destination);
  bus = { ctx, master, sfx };
  return bus;
}

export function unlockAudio() {
  const b = getBus();
  if (!b) return;
  if (b.ctx.state === "suspended") {
    void b.ctx.resume();
  }
}

export function setMuted(muted: boolean) {
  const b = getBus();
  if (!b) return;
  b.master.gain.setTargetAtTime(muted ? 0 : 0.7, b.ctx.currentTime, 0.02);
}

function tone(
  freq: number,
  dur: number,
  type: OscillatorType = "sine",
  gain = 0.16,
  slide = 0,
) {
  const b = getBus();
  if (!b) return;
  const t = b.ctx.currentTime;
  const osc = b.ctx.createOscillator();
  const g = b.ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + 0.018);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(g);
  g.connect(b.sfx);
  osc.start(t);
  osc.stop(t + dur + 0.02);
  osc.onended = () => {
    osc.disconnect();
    g.disconnect();
  };
}

export const sfx = {
  tap() {
    tone(520 + Math.random() * 40, 0.09, "triangle", 0.1, 80);
  },
  pet() {
    tone(420, 0.12, "sine", 0.12, 160);
    setTimeout(() => tone(640, 0.14, "sine", 0.09, 40), 70);
  },
  eat() {
    tone(280, 0.08, "square", 0.06, -40);
    setTimeout(() => tone(220, 0.1, "square", 0.05, -20), 90);
  },
  hatch() {
    tone(360, 0.16, "triangle", 0.14, 220);
    setTimeout(() => tone(540, 0.22, "sine", 0.12, 180), 120);
    setTimeout(() => tone(760, 0.28, "sine", 0.1, 40), 240);
  },
  chime() {
    tone(660, 0.18, "sine", 0.1, 20);
    setTimeout(() => tone(880, 0.22, "sine", 0.08, 10), 90);
  },
  bath() {
    tone(480, 0.1, "sine", 0.08, 120);
    setTimeout(() => tone(520, 0.12, "sine", 0.07, 80), 80);
  },
  sleep() {
    tone(240, 0.28, "sine", 0.1, -80);
    setTimeout(() => tone(180, 0.34, "sine", 0.08, -40), 160);
  },
  coin() {
    tone(880, 0.08, "triangle", 0.09, 40);
    setTimeout(() => tone(1180, 0.12, "triangle", 0.08, 20), 60);
  },
  catch() {
    const f = 640 + Math.random() * 180;
    tone(f, 0.09, "triangle", 0.09, 60);
  },
  deny() {
    tone(180, 0.16, "square", 0.06, -40);
  },
};
