import { defaultState, SAVE_KEY, SAVE_VERSION } from "./constants";
import type { GameState } from "./types";

function migrate(raw: GameState): GameState {
  const base = defaultState(raw.createdAt ?? Date.now());
  const merged: GameState = {
    ...base,
    ...raw,
    inventory: { ...base.inventory, ...raw.inventory },
    evolvedAt: { ...base.evolvedAt, ...raw.evolvedAt },
    events: Array.isArray(raw.events) ? raw.events.slice(-40) : base.events,
    decor: Array.isArray(raw.decor) ? raw.decor : base.decor,
  };
  merged.version = SAVE_VERSION;
  return merged;
}

export function loadSave(): GameState | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as GameState;
    if (!parsed || typeof parsed !== "object") return null;
    return migrate(parsed);
  } catch {
    return null;
  }
}

export function writeSave(state: GameState) {
  try {
    const prev = localStorage.getItem(SAVE_KEY);
    if (prev) localStorage.setItem(SAVE_KEY + ":bak", prev);
    localStorage.setItem(SAVE_KEY, JSON.stringify(state));
  } catch {
    /* private mode / quota — keep playing in memory */
  }
}

export function clearSave() {
  try {
    localStorage.removeItem(SAVE_KEY);
  } catch {
    /* ignore */
  }
}
