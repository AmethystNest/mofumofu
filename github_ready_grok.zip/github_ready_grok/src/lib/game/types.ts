export type Stage = "egg" | "baby" | "child" | "adult";
export type Pose = "idle" | "happy" | "sleep" | "eat" | "sad";
export type Screen = "title" | "hatch" | "room" | "play";
export type Panel = "feed" | "shop" | "diary" | null;
export type FoodId = "apple" | "pancake" | "parfait" | "cookie";
export type DecorId = "cushion" | "plant" | "stars" | "lamp";

export type FoodItem = {
  id: FoodId;
  name: string;
  hunger: number;
  mood: number;
  price: number;
  frame: 1 | 2 | 3 | 4;
};

export type GameEvent = {
  id: string;
  at: number;
  text: string;
};

export type GameState = {
  version: number;
  name: string;
  createdAt: number;
  lastTickAt: number;
  hatchedAt: number | null;
  ageMs: number;
  stage: Stage;
  hunger: number;
  mood: number;
  clean: number;
  energy: number;
  affection: number;
  coins: number;
  sleeping: boolean;
  sleepUntil: number | null;
  inventory: Record<FoodId, number>;
  decor: DecorId[];
  day: number;
  events: GameEvent[];
  tapCount: number;
  feedCount: number;
  playCount: number;
  bathCount: number;
  lastPetAt: number;
  evolvedAt: Partial<Record<Stage, number>>;
};
