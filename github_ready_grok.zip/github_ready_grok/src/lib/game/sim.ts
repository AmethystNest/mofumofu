import { clamp01to100, DAY_MS, FOODS, HOUR_MS } from "./constants";
import type { FoodId, GameEvent, GameState, Stage } from "./types";

function pushEvent(state: GameState, text: string, at: number): GameEvent[] {
  const next = [
    ...state.events,
    { id: `${at}-${Math.random().toString(36).slice(2, 7)}`, at, text },
  ];
  return next.slice(-40);
}

function maybeEvolve(state: GameState, now: number): GameState {
  if (state.stage === "egg" || !state.hatchedAt) return state;
  const ageDays = state.ageMs / DAY_MS;
  let stage: Stage = state.stage;
  const evolvedAt = { ...state.evolvedAt };
  let events = state.events;

  if (stage === "baby" && ageDays >= 0.9 && state.affection >= 12) {
    stage = "child";
    evolvedAt.child = now;
    events = pushEvent(state, `${state.name}は すこし おおきくなった。`, now);
  } else if (stage === "child" && ageDays >= 2.1 && state.affection >= 36) {
    stage = "adult";
    evolvedAt.adult = now;
    events = pushEvent(
      { ...state, events },
      `${state.name}は おとなになった。頭に 小さな葉が さいた。`,
      now,
    );
  }

  if (stage === state.stage) return state;
  return { ...state, stage, evolvedAt, events };
}

export function applyElapsed(state: GameState, now: number): GameState {
  if (state.stage === "egg" || !state.hatchedAt) {
    return { ...state, lastTickAt: now };
  }

  const rawDt = Math.max(0, now - state.lastTickAt);
  const dt = Math.min(rawDt, DAY_MS * 2.5);
  if (dt < 250) return { ...state, lastTickAt: now };

  const hours = dt / HOUR_MS;
  let hunger = state.hunger;
  let mood = state.mood;
  let clean = state.clean;
  let energy = state.energy;
  let sleeping = state.sleeping;
  let sleepUntil = state.sleepUntil;
  let events = state.events;

  if (sleeping && sleepUntil && now >= sleepUntil) {
    sleeping = false;
    sleepUntil = null;
    energy = clamp01to100(energy + 28);
    mood = clamp01to100(mood + 8);
    events = pushEvent({ ...state, events }, `${state.name}が 目をさました。`, now);
  }

  if (sleeping) {
    energy = clamp01to100(energy + hours * 14);
    hunger = clamp01to100(hunger - hours * 1.4);
    mood = clamp01to100(mood + hours * 0.6);
    clean = clamp01to100(clean - hours * 0.4);
  } else {
    hunger = clamp01to100(hunger - hours * 5.4);
    energy = clamp01to100(energy - hours * 3.2);
    clean = clamp01to100(clean - hours * 2.6);
    let moodDrop = hours * 1.4;
    if (hunger < 28) moodDrop += hours * 2.2;
    if (clean < 28) moodDrop += hours * 1.6;
    if (energy < 18) moodDrop += hours * 1.2;
    mood = clamp01to100(mood - moodDrop);
  }

  const ageMs = state.ageMs + dt;
  const day = 1 + Math.floor(ageMs / DAY_MS);

  let next: GameState = {
    ...state,
    hunger,
    mood,
    clean,
    energy,
    sleeping,
    sleepUntil,
    ageMs,
    day,
    events,
    lastTickAt: now,
  };
  next = maybeEvolve(next, now);
  return next;
}

export function pet(state: GameState, now: number): GameState {
  if (state.stage === "egg" || state.sleeping) return state;
  if (now - state.lastPetAt < 2800) return state;
  const bonus = state.clean > 40 ? 5 : 2;
  return {
    ...state,
    mood: clamp01to100(state.mood + bonus),
    affection: state.affection + 1,
    lastPetAt: now,
    tapCount: state.tapCount + 1,
  };
}

export function feed(state: GameState, foodId: FoodId, now: number): GameState | null {
  if (state.stage === "egg" || state.sleeping) return null;
  const count = state.inventory[foodId] ?? 0;
  if (count <= 0) return null;
  const food = FOODS.find((f) => f.id === foodId);
  if (!food) return null;
  return {
    ...state,
    inventory: { ...state.inventory, [foodId]: count - 1 },
    hunger: clamp01to100(state.hunger + food.hunger),
    mood: clamp01to100(state.mood + food.mood),
    energy: clamp01to100(state.energy - 2),
    affection: state.affection + 2,
    feedCount: state.feedCount + 1,
    events: pushEvent(state, `${state.name}は ${food.name}を たべた。`, now),
    lastTickAt: now,
  };
}

export function bath(state: GameState, now: number): GameState {
  if (state.stage === "egg" || state.sleeping) return state;
  return {
    ...state,
    clean: clamp01to100(state.clean + 42),
    mood: clamp01to100(state.mood + 8),
    energy: clamp01to100(state.energy - 6),
    affection: state.affection + 2,
    bathCount: state.bathCount + 1,
    events: pushEvent(state, `${state.name}を おふろに いれた。`, now),
    lastTickAt: now,
  };
}

export function startSleep(state: GameState, now: number): GameState {
  if (state.stage === "egg" || state.sleeping) return state;
  return {
    ...state,
    sleeping: true,
    sleepUntil: now + HOUR_MS * 8,
    events: pushEvent(state, `${state.name}は やわらかい夢に もぐった。`, now),
    lastTickAt: now,
  };
}

export function wake(state: GameState, now: number): GameState {
  if (!state.sleeping) return state;
  return {
    ...state,
    sleeping: false,
    sleepUntil: null,
    energy: clamp01to100(state.energy + 10),
    events: pushEvent(state, `${state.name}を おこした。`, now),
    lastTickAt: now,
  };
}

export function finishPlay(state: GameState, score: number, now: number): GameState {
  const coins = 6 + score * 2;
  const mood = 10 + Math.min(22, score * 3);
  return {
    ...state,
    coins: state.coins + coins,
    mood: clamp01to100(state.mood + mood),
    energy: clamp01to100(state.energy - 12),
    hunger: clamp01to100(state.hunger - 6),
    affection: state.affection + 3 + Math.min(6, score),
    playCount: state.playCount + 1,
    events: pushEvent(state, `${state.name}と あそんだ。おやつを ${score}こ とった。`, now),
    lastTickAt: now,
  };
}

export function buyFood(state: GameState, foodId: FoodId): GameState | null {
  const food = FOODS.find((f) => f.id === foodId);
  if (!food) return null;
  if (state.coins < food.price) return null;
  return {
    ...state,
    coins: state.coins - food.price,
    inventory: { ...state.inventory, [foodId]: (state.inventory[foodId] ?? 0) + 1 },
  };
}

export function buyDecor(state: GameState, id: GameState["decor"][number]): GameState | null {
  const item = (
    [
      { id: "cushion", price: 40 },
      { id: "plant", price: 55 },
      { id: "stars", price: 70 },
      { id: "lamp", price: 85 },
    ] as const
  ).find((d) => d.id === id);
  if (!item) return null;
  if (state.decor.includes(id)) return state;
  if (state.coins < item.price) return null;
  return {
    ...state,
    coins: state.coins - item.price,
    decor: [...state.decor, id],
  };
}

export function hatch(state: GameState, now: number): GameState {
  return {
    ...state,
    stage: "baby",
    hatchedAt: now,
    ageMs: 0,
    hunger: 68,
    mood: 82,
    clean: 88,
    energy: 74,
    affection: 6,
    sleeping: false,
    evolvedAt: { baby: now },
    events: pushEvent(state, `${state.name}が うまれた。`, now),
    lastTickAt: now,
  };
}

export function healthScore(state: GameState) {
  return (state.hunger + state.mood + state.clean + state.energy) / 4;
}

export function isNight(state: GameState, now: number) {
  if (state.sleeping) return true;
  if (state.stage === "egg") return false;
  const hour = Math.floor(((state.ageMs + (now - state.lastTickAt)) / HOUR_MS) % 24);
  return hour >= 20 || hour < 6;
}

export function speechFor(state: GameState): string {
  if (state.stage === "egg") return "……（なかで うごいてる）";
  if (state.sleeping) return "すやすや……";
  if (state.hunger < 25) return "おなか すいた……";
  if (state.clean < 28) return "ちょっと べたべた";
  if (state.energy < 20) return "ねむい……";
  if (state.mood < 30) return "……しょんぼり";
  if (state.mood >= 85) return "もふっ　きもちいい";
  if (state.hunger > 85) return "おなか いっぱい";
  const lines = ["ふわふわ", "なでて？", "きょうも いっしょ", "もぐもぐ……", "にこっ"];
  return lines[state.day % lines.length]!;
}
