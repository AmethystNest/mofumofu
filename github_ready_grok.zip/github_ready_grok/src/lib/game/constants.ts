import type { FoodItem, GameState } from "./types";

export const SAVE_KEY = "mofurun-save-v1";
export const SAVE_VERSION = 1;

/** One game-day is 90 real seconds so a session can grow a pet. */
export const DAY_MS = 90_000;
export const HOUR_MS = DAY_MS / 24;

export const FOODS: FoodItem[] = [
  { id: "apple", name: "りんご", hunger: 22, mood: 4, price: 12, frame: 1 },
  { id: "pancake", name: "パンケーキ", hunger: 34, mood: 10, price: 22, frame: 2 },
  { id: "parfait", name: "パフェ", hunger: 28, mood: 18, price: 28, frame: 3 },
  { id: "cookie", name: "クッキー", hunger: 16, mood: 12, price: 16, frame: 4 },
];

export const DECOR_SHOP: { id: GameState["decor"][number]; name: string; price: number; hint: string }[] =
  [
    { id: "cushion", name: "まるざぶとん", price: 40, hint: "お気に入りの場所" },
    { id: "plant", name: "みどりの鉢", price: 55, hint: "部屋がやわらかくなる" },
    { id: "stars", name: "かみのほし", price: 70, hint: "きらめきが増える" },
    { id: "lamp", name: "あたたかランプ", price: 85, hint: "夜がやさしくなる" },
  ];

export const STAGE_LABEL: Record<GameState["stage"], string> = {
  egg: "たまご",
  baby: "あかちゃん",
  child: "こども",
  adult: "おとな",
};

export const defaultState = (now = Date.now()): GameState => ({
  version: SAVE_VERSION,
  name: "もふるん",
  createdAt: now,
  lastTickAt: now,
  hatchedAt: null,
  ageMs: 0,
  stage: "egg",
  hunger: 72,
  mood: 70,
  clean: 80,
  energy: 78,
  affection: 0,
  coins: 40,
  sleeping: false,
  sleepUntil: null,
  inventory: { apple: 3, pancake: 1, parfait: 0, cookie: 1 },
  decor: ["cushion"],
  day: 1,
  events: [
    {
      id: "born",
      at: now,
      text: "あたたかい部屋に、ひとつのたまごが置かれた。",
    },
  ],
  tapCount: 0,
  feedCount: 0,
  playCount: 0,
  bathCount: 0,
  lastPetAt: 0,
  evolvedAt: {},
});

export function clamp01to100(n: number) {
  return Math.max(0, Math.min(100, n));
}

export function moodLabel(mood: number, sleeping: boolean): string {
  if (sleeping) return "すやすや";
  if (mood >= 80) return "ごきげん";
  if (mood >= 55) return "ふつう";
  if (mood >= 30) return "ちょっとしょんぼり";
  return "かなしい";
}
