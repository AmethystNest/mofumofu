import { create } from "zustand";
import { defaultState } from "./constants";
import { clearSave, loadSave, writeSave } from "./save";
import {
  applyElapsed,
  bath,
  buyDecor,
  buyFood,
  feed,
  finishPlay,
  hatch,
  pet,
  startSleep,
  wake,
} from "./sim";
import type { DecorId, FoodId, GameState, Panel, Screen } from "./types";

type Toast = { id: number; text: string } | null;

type GameStore = {
  hasSave: boolean;
  state: GameState;
  screen: Screen;
  panel: Panel;
  muted: boolean;
  poseUntil: number;
  pose: "idle" | "happy" | "sleep" | "eat";
  toast: Toast;
  floating: { id: number }[];
  hydrate: () => void;
  setScreen: (screen: Screen) => void;
  setPanel: (panel: Panel) => void;
  newGame: (name: string) => void;
  continueGame: () => void;
  tick: (now: number) => void;
  hatchPet: () => void;
  petPet: () => void;
  feedPet: (id: FoodId) => boolean;
  bathPet: () => void;
  sleepPet: () => void;
  wakePet: () => void;
  endPlay: (score: number) => void;
  purchaseFood: (id: FoodId) => boolean;
  purchaseDecor: (id: DecorId) => boolean;
  reset: () => void;
  toggleMute: () => void;
  pushToast: (text: string) => void;
};

let toastSeq = 1;
let floatSeq = 1;
let saveTimer: ReturnType<typeof setTimeout> | null = null;
let hydrated = false;

function scheduleSave(state: GameState) {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => writeSave(state), 400);
}

export const useGame = create<GameStore>((set, get) => ({
  hasSave: false,
  state: defaultState(),
  screen: "title",
  panel: null,
  muted: false,
  poseUntil: 0,
  pose: "idle",
  toast: null,
  floating: [],

  hydrate() {
    if (hydrated) return;
    hydrated = true;
    const saved = loadSave();
    if (saved) {
      const now = Date.now();
      const state = applyElapsed(saved, now);
      set({
        hasSave: true,
        state,
        screen: "title",
        pose: state.sleeping ? "sleep" : "idle",
      });
      writeSave(state);
    }
  },

  setScreen(screen) {
    set({ screen, panel: null });
  },

  setPanel(panel) {
    set({ panel });
  },

  newGame(name) {
    const now = Date.now();
    const state = defaultState(now);
    state.name = name.trim().slice(0, 8) || "もふるん";
    clearSave();
    writeSave(state);
    set({
      state,
      hasSave: true,
      screen: "hatch",
      panel: null,
      pose: "idle",
      poseUntil: 0,
      floating: [],
    });
  },

  continueGame() {
    const { state } = get();
    set({
      screen: state.stage === "egg" ? "hatch" : "room",
      panel: null,
    });
  },

  tick(now) {
    const next = applyElapsed(get().state, now);
    const pose = next.sleeping ? "sleep" : now < get().poseUntil ? get().pose : "idle";
    set({ state: next, pose });
    if (get().hasSave) scheduleSave(next);
  },

  hatchPet() {
    const now = Date.now();
    const state = hatch(get().state, now);
    set({ state, screen: "room", pose: "happy", poseUntil: now + 2200 });
    writeSave(state);
  },

  petPet() {
    const now = Date.now();
    const prev = get().state;
    const next = pet(prev, now);
    if (next === prev) return;
    const id = floatSeq++;
    set({
      state: next,
      pose: "happy",
      poseUntil: now + 1400,
      floating: [...get().floating.slice(-8), { id }],
    });
    scheduleSave(next);
    setTimeout(() => {
      set((s) => ({ floating: s.floating.filter((f) => f.id !== id) }));
    }, 900);
  },

  feedPet(id) {
    const now = Date.now();
    const next = feed(get().state, id, now);
    if (!next) return false;
    set({ state: next, pose: "eat", poseUntil: now + 1600, panel: null });
    scheduleSave(next);
    get().pushToast(`${next.name}は おいしそう`);
    return true;
  },

  bathPet() {
    const now = Date.now();
    const next = bath(get().state, now);
    set({ state: next, pose: "happy", poseUntil: now + 1800 });
    scheduleSave(next);
    get().pushToast("さっぱりした");
  },

  sleepPet() {
    const now = Date.now();
    const next = startSleep(get().state, now);
    set({ state: next, pose: "sleep", poseUntil: next.sleepUntil ?? now });
    scheduleSave(next);
  },

  wakePet() {
    const now = Date.now();
    const next = wake(get().state, now);
    set({ state: next, pose: "idle", poseUntil: 0 });
    scheduleSave(next);
  },

  endPlay(score) {
    const now = Date.now();
    const next = finishPlay(get().state, score, now);
    set({
      state: next,
      screen: "room",
      pose: "happy",
      poseUntil: now + 2000,
    });
    writeSave(next);
    get().pushToast(`コイン +${6 + score * 2}`);
  },

  purchaseFood(id) {
    const next = buyFood(get().state, id);
    if (!next) return false;
    set({ state: next });
    scheduleSave(next);
    return true;
  },

  purchaseDecor(id) {
    const next = buyDecor(get().state, id);
    if (!next) return false;
    set({ state: next });
    scheduleSave(next);
    get().pushToast("部屋に おいた");
    return true;
  },

  reset() {
    clearSave();
    hydrated = true;
    const state = defaultState();
    set({
      state,
      hasSave: false,
      screen: "title",
      panel: null,
      pose: "idle",
      poseUntil: 0,
      floating: [],
    });
  },

  toggleMute() {
    set({ muted: !get().muted });
  },

  pushToast(text) {
    const id = toastSeq++;
    set({ toast: { id, text } });
    setTimeout(() => {
      set((s) => (s.toast?.id === id ? { toast: null } : s));
    }, 1600);
  },
}));
