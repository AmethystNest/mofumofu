import { Bath, BookOpen, Moon, ShoppingBag, Sparkles, UtensilsCrossed } from "lucide-react";
import { sfx, unlockAudio } from "@/lib/game/audio";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";

export function ActionDock() {
  const state = useGame((s) => s.state);
  const panel = useGame((s) => s.panel);
  const setPanel = useGame((s) => s.setPanel);
  const setScreen = useGame((s) => s.setScreen);
  const bathPet = useGame((s) => s.bathPet);
  const sleepPet = useGame((s) => s.sleepPet);
  const wakePet = useGame((s) => s.wakePet);
  const pushToast = useGame((s) => s.pushToast);
  const locked = state.stage === "egg";

  const items = [
    { id: "feed" as const, label: "ごはん", icon: UtensilsCrossed, active: panel === "feed" },
    { id: "play" as const, label: "あそぶ", icon: Sparkles, active: false },
    { id: "bath" as const, label: "おふろ", icon: Bath, active: false },
    {
      id: "sleep" as const,
      label: state.sleeping ? "おきて" : "おやすみ",
      icon: Moon,
      active: state.sleeping,
    },
    { id: "shop" as const, label: "おみせ", icon: ShoppingBag, active: panel === "shop" },
  ];

  function onAction(id: (typeof items)[number]["id"]) {
    unlockAudio();
    if (locked) {
      sfx.deny();
      pushToast("まだ たまごだよ");
      return;
    }
    if (state.sleeping && id !== "sleep") {
      sfx.deny();
      pushToast("いまは ねてる");
      return;
    }
    if (id === "feed") {
      sfx.tap();
      setPanel(panel === "feed" ? null : "feed");
      return;
    }
    if (id === "play") {
      if (state.energy < 16) {
        sfx.deny();
        pushToast("ちょっと つかれてる");
        return;
      }
      sfx.chime();
      setScreen("play");
      return;
    }
    if (id === "bath") {
      sfx.bath();
      bathPet();
      return;
    }
    if (id === "sleep") {
      if (state.sleeping) {
        sfx.tap();
        wakePet();
        return;
      }
      sfx.sleep();
      sleepPet();
      return;
    }
    sfx.tap();
    setPanel(panel === "shop" ? null : "shop");
  }

  return (
    <nav className="relative z-10 px-3 pb-[max(0.7rem,env(safe-area-inset-bottom))] pt-1">
      <div className="mb-1 flex justify-end px-1">
        <button
          type="button"
          onClick={() => {
            unlockAudio();
            sfx.tap();
            setPanel(panel === "diary" ? null : "diary");
          }}
          className="inline-flex h-8 items-center gap-1 rounded-pill px-2 text-xs text-muted hover:text-ink"
        >
          <BookOpen className="size-3.5" />
          にっき
        </button>
      </div>
      <div className="grid grid-cols-5 gap-1 rounded-2xl border border-line bg-surface/92 p-1.5 shadow-lift backdrop-blur-md">
        {items.map((a) => {
          const Icon = a.icon;
          return (
            <button
              key={a.id}
              type="button"
              onClick={() => onAction(a.id)}
              className={cn(
                "flex min-h-14 flex-col items-center justify-center gap-1 rounded-xl px-1",
                "text-[11px] font-medium transition-colors duration-150",
                a.active ? "bg-coral/15 text-coral-deep" : "text-ink hover:bg-surface-2",
              )}
            >
              <Icon className="size-5" strokeWidth={2} />
              {a.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
