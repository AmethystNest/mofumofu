import { useEffect, useRef, useState, type MutableRefObject } from "react";
import { Button } from "@/components/ui/button";
import { sfx, unlockAudio } from "@/lib/game/audio";
import { useGame } from "@/lib/game/store";

type Drop = { id: number; x: number; y: number; vy: number; frame: 1 | 2 | 3 | 4 };

const GAME_MS = 12_000;

export function PlayMinigame() {
  const endPlay = useGame((s) => s.endPlay);
  const setScreen = useGame((s) => s.setScreen);
  const [score, setScore] = useState(0);
  const [left, setLeft] = useState(GAME_MS);
  const [running, setRunning] = useState(false);
  const drops = useRef<Drop[]>([]);
  const scoreRef = useRef(0);
  const idRef = useRef(1);

  useEffect(() => {
    if (!running) return;
    let raf = 0;
    let last = performance.now();
    let elapsed = 0;
    let spawnAcc = 0;
    let cancelled = false;
    const loop = (t: number) => {
      if (cancelled) return;
      const dt = Math.min((t - last) / 1000, 0.1);
      last = t;
      elapsed += dt * 1000;
      spawnAcc += dt;
      const remain = Math.max(0, GAME_MS - elapsed);
      setLeft(remain);

      if (spawnAcc > 0.55) {
        spawnAcc = 0;
        drops.current.push({
          id: idRef.current++,
          x: 8 + Math.random() * 74,
          y: -12,
          vy: 28 + Math.random() * 22,
          frame: (1 + Math.floor(Math.random() * 4)) as 1 | 2 | 3 | 4,
        });
      }

      drops.current = drops.current
        .map((d) => ({ ...d, y: d.y + d.vy * dt }))
        .filter((d) => d.y < 112);

      if (remain <= 0) {
        endPlay(scoreRef.current);
        return;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
    };
  }, [running, endPlay]);

  function catchDrop(id: number) {
    drops.current = drops.current.filter((d) => d.id !== id);
    scoreRef.current += 1;
    setScore(scoreRef.current);
    sfx.catch();
  }

  return (
    <div className="flex h-dvh flex-col bg-bg">
      <header className="flex items-center justify-between px-5 pt-[max(0.9rem,env(safe-area-inset-top))]">
        <p className="text-sm text-muted">おやつキャッチ</p>
        <p className="text-sm tabular-nums text-ink">
          {Math.ceil(left / 1000)}秒 · {score}こ
        </p>
      </header>
      <div className="relative mx-3 mt-2 min-h-0 flex-1 overflow-hidden rounded-xl border border-line bg-surface-2">
        {!running ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-6 text-center">
            <p className="font-display text-xl text-ink">落ちてくるおやつを タップ</p>
            <p className="text-sm text-muted">12秒で たくさん とろう</p>
            <Button
              size="xl"
              onClick={() => {
                unlockAudio();
                sfx.chime();
                setRunning(true);
              }}
            >
              はじめる
            </Button>
            <Button variant="ghost" onClick={() => setScreen("room")}>
              やめる
            </Button>
          </div>
        ) : (
          <FallingLayer drops={drops} onCatch={catchDrop} />
        )}
      </div>
      <p className="px-5 py-3 pb-[max(1rem,env(safe-area-inset-bottom))] text-center text-xs text-muted">
        とった数だけ コインと きぶんが ふえる
      </p>
    </div>
  );
}

function FallingLayer({
  drops,
  onCatch,
}: {
  drops: MutableRefObject<Drop[]>;
  onCatch: (id: number) => void;
}) {
  const [, bump] = useState(0);
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      bump((n) => n + 1);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <>
      {drops.current.map((d) => (
        <button
          key={d.id}
          type="button"
          className="absolute size-[18%] -translate-x-1/2 touch-manipulation"
          style={{ left: `${d.x}%`, top: `${d.y}%` }}
          onPointerDown={(e) => {
            e.preventDefault();
            onCatch(d.id);
          }}
          aria-label="おやつ"
        >
          <img src={`/sprites/food/f${d.frame}.png`} alt="" className="h-full w-full object-contain" />
        </button>
      ))}
    </>
  );
}
