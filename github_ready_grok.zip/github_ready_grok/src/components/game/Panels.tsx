import { useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DECOR_SHOP, FOODS, STAGE_LABEL } from "@/lib/game/constants";
import { sfx } from "@/lib/game/audio";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";
import type { Panel } from "@/lib/game/types";

export function OverlayPanel() {
  const panel = useGame((s) => s.panel);
  const setPanel = useGame((s) => s.setPanel);
  if (!panel) return null;
  const title = panel === "feed" ? "ごはん" : panel === "shop" ? "おみせ" : "にっき";
  return (
    <div className="absolute inset-0 z-20 flex items-end bg-ink/25">
      <button
        type="button"
        className="absolute inset-0"
        aria-label="閉じる"
        onClick={() => setPanel(null)}
      />
      <section className="relative max-h-[72%] w-full rounded-t-2xl border border-line bg-surface p-4 pb-[max(1rem,env(safe-area-inset-bottom))] shadow-lift">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-lg font-medium text-ink">{title}</h2>
          <button
            type="button"
            onClick={() => setPanel(null)}
            className="inline-flex size-10 items-center justify-center rounded-md text-muted"
            aria-label="閉じる"
          >
            <X className="size-5" />
          </button>
        </div>
        {panel === "feed" ? <FeedBody /> : null}
        {panel === "shop" ? <ShopBody /> : null}
        {panel === "diary" ? <DiaryBody /> : null}
      </section>
    </div>
  );
}

function FeedBody() {
  const inventory = useGame((s) => s.state.inventory);
  const feedPet = useGame((s) => s.feedPet);
  const pushToast = useGame((s) => s.pushToast);

  return (
    <ul className="grid grid-cols-2 gap-2">
      {FOODS.map((food) => {
        const n = inventory[food.id] ?? 0;
        return (
          <li key={food.id}>
            <button
              type="button"
              disabled={n <= 0}
              onClick={() => {
                const ok = feedPet(food.id);
                if (ok) sfx.eat();
                else {
                  sfx.deny();
                  pushToast("ないよ");
                }
              }}
              className={cn(
                "flex w-full items-center gap-2 rounded-lg border border-line bg-bg px-2 py-2 text-left",
                n <= 0 && "opacity-45",
              )}
            >
              <img src={`/sprites/food/f${food.frame}.png`} alt="" className="size-12 object-contain" />
              <span>
                <span className="block text-sm font-medium text-ink">{food.name}</span>
                <span className="text-xs tabular-nums text-muted">×{n}</span>
              </span>
            </button>
          </li>
        );
      })}
    </ul>
  );
}

function ShopBody() {
  const [tab, setTab] = useState<"food" | "room">("food");
  const coins = useGame((s) => s.state.coins);
  const inventory = useGame((s) => s.state.inventory);
  const decor = useGame((s) => s.state.decor);
  const purchaseFood = useGame((s) => s.purchaseFood);
  const purchaseDecor = useGame((s) => s.purchaseDecor);
  const pushToast = useGame((s) => s.pushToast);

  return (
    <div>
      <div className="mb-3 flex gap-1 rounded-md bg-bg p-1">
        {(["food", "room"] as const).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTab(t)}
            className={cn(
              "h-9 flex-1 rounded-sm text-sm font-medium",
              tab === t ? "bg-surface text-ink shadow-soft" : "text-muted",
            )}
          >
            {t === "food" ? "たべもの" : "へや"}
          </button>
        ))}
      </div>
      <p className="mb-2 text-xs tabular-nums text-muted">コイン {coins}</p>
      {tab === "food" ? (
        <ul className="flex flex-col gap-2">
          {FOODS.map((food) => (
            <li
              key={food.id}
              className="flex items-center gap-3 rounded-lg border border-line bg-bg px-2 py-2"
            >
              <img src={`/sprites/food/f${food.frame}.png`} alt="" className="size-12 object-contain" />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-ink">{food.name}</p>
                <p className="text-xs text-muted">
                  おなか +{food.hunger} · きぶん +{food.mood} · もち {inventory[food.id]}
                </p>
              </div>
              <Button
                size="md"
                onClick={() => {
                  const ok = purchaseFood(food.id);
                  if (ok) sfx.coin();
                  else {
                    sfx.deny();
                    pushToast("コインが たりない");
                  }
                }}
              >
                {food.price}
              </Button>
            </li>
          ))}
        </ul>
      ) : (
        <ul className="flex flex-col gap-2">
          {DECOR_SHOP.map((item) => {
            const owned = decor.includes(item.id);
            return (
              <li
                key={item.id}
                className="flex items-center gap-3 rounded-lg border border-line bg-bg px-3 py-3"
              >
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-ink">{item.name}</p>
                  <p className="text-xs text-muted">{item.hint}</p>
                </div>
                {owned ? (
                  <span className="text-xs text-sage">おいた</span>
                ) : (
                  <Button
                    size="md"
                    onClick={() => {
                      const ok = purchaseDecor(item.id);
                      if (ok) sfx.coin();
                      else {
                        sfx.deny();
                        pushToast("コインが たりない");
                      }
                    }}
                  >
                    {item.price}
                  </Button>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function DiaryBody() {
  const state = useGame((s) => s.state);
  const reset = useGame((s) => s.reset);
  return (
    <div className="flex max-h-[52vh] flex-col gap-3 overflow-y-auto">
      <p className="text-sm text-muted">
        {STAGE_LABEL[state.stage]} · なでた {state.tapCount} · ごはん {state.feedCount} · あそび{" "}
        {state.playCount}
      </p>
      <ul className="flex flex-col gap-2">
        {[...state.events].reverse().map((ev) => (
          <li key={ev.id} className="rounded-md bg-bg px-3 py-2 text-sm text-ink">
            {ev.text}
          </li>
        ))}
      </ul>
      <Button variant="ghost" className="mt-2 text-muted" onClick={() => reset()}>
        さいしょから
      </Button>
    </div>
  );
}

export type { Panel };
