import type { ReactNode } from "react";

export function PhoneShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh items-stretch justify-center bg-bg-deep">
      <div className="relative h-dvh w-full max-w-[430px] overflow-hidden bg-bg shadow-lift sm:my-0">
        {children}
      </div>
    </div>
  );
}
