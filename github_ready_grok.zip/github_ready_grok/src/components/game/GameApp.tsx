import { useEffect, useLayoutEffect } from "react";
import { HatchScreen } from "./HatchScreen";
import { PhoneShell } from "./PhoneShell";
import { PlayMinigame } from "./PlayMinigame";
import { RoomScreen } from "./RoomScreen";
import { TitleScreen } from "./TitleScreen";
import { setMuted, unlockAudio } from "@/lib/game/audio";
import { writeSave } from "@/lib/game/save";
import { useGame } from "@/lib/game/store";

export function GameApp() {
  const screen = useGame((s) => s.screen);
  const muted = useGame((s) => s.muted);
  const hydrate = useGame((s) => s.hydrate);
  const tick = useGame((s) => s.tick);

  useLayoutEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    setMuted(muted);
  }, [muted]);

  useEffect(() => {
    let raf = 0;
    let acc = 0;
    let last = performance.now();
    const loop = (t: number) => {
      const dt = Math.min((t - last) / 1000, 0.1);
      last = t;
      acc += dt;
      if (acc >= 0.35) {
        acc = 0;
        tick(Date.now());
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [tick]);

  useEffect(() => {
    const onHide = () => {
      if (document.visibilityState === "hidden") {
        writeSave(useGame.getState().state);
      } else {
        unlockAudio();
        tick(Date.now());
      }
    };
    document.addEventListener("visibilitychange", onHide);
    window.addEventListener("pagehide", onHide);
    return () => {
      document.removeEventListener("visibilitychange", onHide);
      window.removeEventListener("pagehide", onHide);
    };
  }, [tick]);

  const inner =
    screen === "title" ? (
      <TitleScreen />
    ) : screen === "hatch" ? (
      <HatchScreen />
    ) : screen === "play" ? (
      <PlayMinigame />
    ) : (
      <RoomScreen />
    );

  return <PhoneShell>{inner}</PhoneShell>;
}
