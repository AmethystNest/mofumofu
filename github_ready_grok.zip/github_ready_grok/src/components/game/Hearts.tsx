import { Heart } from "lucide-react";
import { useGame } from "@/lib/game/store";

export function Hearts() {
  const floating = useGame((s) => s.floating);
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {floating.map((f, i) => (
        <span
          key={f.id}
          className="absolute left-1/2 animate-[heart-rise_0.9s_var(--ease-smooth-out)_forwards] text-coral"
          style={{
            marginLeft: `${(i % 3) * 22 - 22}px`,
            bottom: "42%",
          }}
        >
          <Heart className="size-5 fill-coral" strokeWidth={0} />
        </span>
      ))}
      <style>{`
        @keyframes heart-rise {
          0% { opacity: 0; transform: translate(-50%, 8px) scale(0.7); }
          20% { opacity: 1; transform: translate(-50%, 0) scale(1); }
          100% { opacity: 0; transform: translate(-50%, -56px) scale(0.9); }
        }
      `}</style>
    </div>
  );
}
