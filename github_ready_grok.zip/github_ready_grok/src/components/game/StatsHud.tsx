import type { ReactNode } from "react";
import { Apple, Bath, Heart, Moon, Sparkles } from "lucide-react";
import { moodLabel, STAGE_LABEL } from "@/lib/game/constants";
import { healthScore } from "@/lib/game/sim";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";

function Meter({
  value,
  label,
  icon,
  tone,
}: {
  value: number;
  label: string;
  icon: ReactNode;
  tone: "coral" | "sage" | "peach" | "ink";
}) {
  const fill =
    tone === "coral"
      ? "bg-coral"
      : tone === "sage"
        ? "bg-sage"
        : tone === "peach"
          ? "bg-peach"
          : "bg-ink/70";
  return (
    <div className="flex min-w-0 flex-col gap-1">
      <div className="flex items-center gap-1 text-muted">
        <span className="size-3.5">{icon}</span>
        <span className="text-[11px] font-medium">{label}</span>
        <span className="ml-auto text-[11px] tabular-nums text-ink/70">{Math.round(value)}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-pill bg-ink/10">
        <div
          className={cn("h-full rounded-pill transition-[width] duration-300", fill)}
          style={{ width: `${Math.max(4, Math.min(100, value))}%` }}
        />
      </div>
    </div>
  );
}

export function StatsHud() {
  const state = useGame((s) => s.state);
  const mood = moodLabel(state.mood, state.sleeping);

  return (
    <header className="pointer-events-none relative z-10 px-4 pt-[max(0.75rem,env(safe-area-inset-top))]">
      <div className="rounded-xl border border-line bg-surface/88 px-3.5 py-3 shadow-soft backdrop-blur-md">
        <div className="mb-3 flex items-baseline justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate font-display text-lg font-medium leading-tight text-ink">
              {state.name}
            </p>
            <p className="text-xs text-muted">
              {STAGE_LABEL[state.stage]} · {mood} · {state.day}日め
            </p>
          </div>
          <div className="flex items-center gap-2 text-sm tabular-nums text-ink">
            <Sparkles className="size-3.5 text-coral" />
            <span className="font-medium">{state.coins}</span>
          </div>
        </div>
        {state.stage === "egg" ? (
          <p className="text-sm text-muted">たまごを つついて うまれさせよう</p>
        ) : (
          <div className="grid grid-cols-2 gap-x-4 gap-y-2.5">
            <Meter value={state.hunger} label="おなか" icon={<Apple className="size-3.5" />} tone="coral" />
            <Meter value={state.mood} label="きぶん" icon={<Heart className="size-3.5" />} tone="coral" />
            <Meter value={state.clean} label="きれい" icon={<Bath className="size-3.5" />} tone="sage" />
            <Meter value={state.energy} label="げんき" icon={<Moon className="size-3.5" />} tone="peach" />
          </div>
        )}
      </div>
    </header>
  );
}
