import { ActionDock } from "./ActionDock";
import { OverlayPanel } from "./Panels";
import { PetView } from "./PetView";
import { StatsHud } from "./StatsHud";
import { isNight, speechFor } from "@/lib/game/sim";
import { useGame } from "@/lib/game/store";
import { cn } from "@/lib/utils";

export function RoomScreen() {
  const state = useGame((s) => s.state);
  const toast = useGame((s) => s.toast);
  const night = isNight(state, Date.now());
  const line = toast?.text ?? speechFor(state);

  return (
    <div className="relative flex h-dvh flex-col overflow-hidden bg-bg">
      <img
        src="/bg/room-day.jpg"
        alt=""
        className="absolute inset-0 h-full w-full object-cover"
      />
      <img
        src="/bg/room-night.jpg"
        alt=""
        className={cn(
          "absolute inset-0 h-full w-full object-cover transition-opacity duration-500",
          night ? "opacity-100" : "opacity-0",
        )}
      />
      <div className={cn("absolute inset-0", night ? "bg-night/20" : "bg-bg/10")} />

      <StatsHud />

      <div className="relative flex min-h-0 flex-1 flex-col">
        <div className="flex justify-center px-6 pt-3">
          <p
            key={line}
            className="max-w-[86%] rounded-xl rounded-bl-sm border border-line bg-surface/92 px-3.5 py-2 text-sm text-ink shadow-soft"
          >
            {line}
          </p>
        </div>
        <PetView />
      </div>

      <ActionDock />
      <OverlayPanel />
    </div>
  );
}
