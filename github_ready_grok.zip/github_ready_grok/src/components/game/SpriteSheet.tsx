import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

type Props = {
  src: string;
  fps?: number;
  className?: string;
  playing?: boolean;
  alt: string;
};

export function SpriteSheet({ src, fps = 4, className, playing = true, alt }: Props) {
  const [frame, setFrame] = useState(0);

  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    let acc = 0;
    let last = performance.now();
    const step = 1 / Math.max(1, fps);
    const loop = (t: number) => {
      const dt = Math.min((t - last) / 1000, 0.1);
      last = t;
      acc += dt;
      if (acc >= step) {
        acc %= step;
        setFrame((f) => (f + 1) % 4);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [fps, playing, src]);

  const col = frame % 2;
  const row = Math.floor(frame / 2);

  return (
    <div
      role="img"
      aria-label={alt}
      className={cn("relative overflow-hidden", className)}
      style={{
        backgroundImage: `url(${src})`,
        backgroundRepeat: "no-repeat",
        backgroundSize: "200% 200%",
        backgroundPosition: `${col * 100}% ${row * 100}%`,
      }}
    />
  );
}
