import { useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SpriteSheet } from "./SpriteSheet";
import { sfx, unlockAudio, setMuted } from "@/lib/game/audio";
import { useGame } from "@/lib/game/store";

export function TitleScreen() {
  const newGame = useGame((s) => s.newGame);
  const continueGame = useGame((s) => s.continueGame);
  const muted = useGame((s) => s.muted);
  const toggleMute = useGame((s) => s.toggleMute);
  const hasSave = useGame((s) => s.hasSave);
  const savedName = useGame((s) => s.state.name);
  const stage = useGame((s) => s.state.stage);
  const [name, setName] = useState(savedName || "もふるん");
  const [naming, setNaming] = useState(false);

  return (
    <div className="relative flex h-dvh flex-col overflow-hidden bg-bg">
      <img
        src="/bg/room-day.jpg"
        alt=""
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-bg/35" />
      <div className="relative flex min-h-0 flex-1 flex-col items-center justify-end px-6 pb-6 pt-[max(1rem,env(safe-area-inset-top))]">
        <div className="mb-auto mt-10 text-center">
          <p className="text-xs font-medium tracking-[0.22em] text-muted">そだてて くらす</p>
          <h1 className="mt-2 font-display text-5xl font-medium tracking-tight text-ink">もふるん</h1>
        </div>
        <SpriteSheet
          src="/sprites/baby-idle/sheet.png"
          fps={4}
          alt="もふるん"
          className="mb-6 h-[42vw] max-h-[240px] w-[42vw] max-w-[240px] drop-shadow-[0_16px_18px_rgb(74_52_44_/_0.2)]"
        />
        <div className="w-full max-w-sm rounded-2xl border border-line bg-surface/92 p-5 shadow-lift backdrop-blur-md">
          {naming ? (
            <form
              className="flex flex-col gap-3"
              onSubmit={(e) => {
                e.preventDefault();
                unlockAudio();
                sfx.chime();
                newGame(name);
              }}
            >
              <label className="text-sm font-medium text-ink" htmlFor="pet-name">
                なまえ
              </label>
              <input
                id="pet-name"
                value={name}
                maxLength={8}
                onChange={(e) => setName(e.target.value)}
                className="h-12 rounded-md border border-line bg-bg px-3 text-base text-ink outline-none ring-coral/40 focus:ring-2"
                autoComplete="off"
              />
              <Button type="submit" size="xl" className="w-full">
                たまごを もらう
              </Button>
              <Button type="button" variant="ghost" onClick={() => setNaming(false)}>
                もどる
              </Button>
            </form>
          ) : (
            <div className="flex flex-col gap-2.5">
              <Button
                size="xl"
                className="w-full"
                onClick={() => {
                  unlockAudio();
                  sfx.tap();
                  setNaming(true);
                }}
              >
                あたらしくはじめる
              </Button>
              {hasSave ? (
                <Button
                  variant="secondary"
                  size="lg"
                  className="w-full"
                  onClick={() => {
                    unlockAudio();
                    sfx.tap();
                    continueGame();
                  }}
                >
                  {stage === "egg" ? "たまごに もどる" : `${savedName}の へやへ`}
                </Button>
              ) : null}
            </div>
          )}
        </div>
        <button
          type="button"
          className="mt-4 inline-flex size-11 items-center justify-center rounded-md text-muted"
          onClick={() => {
            unlockAudio();
            toggleMute();
            setMuted(!muted);
          }}
          aria-label={muted ? "音を出す" : "消音"}
        >
          {muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
        </button>
      </div>
    </div>
  );
}
