import { SpriteSheet } from "./SpriteSheet";
import { Hearts } from "./Hearts";
import { useGame } from "@/lib/game/store";
import { sfx } from "@/lib/game/audio";
import { cn } from "@/lib/utils";
import type { Pose, Stage } from "@/lib/game/types";

function sheetFor(stage: Stage, pose: Pose): { src: string; fps: number } {
  if (stage === "egg") return { src: "/sprites/egg/sheet.png", fps: 3 };
  if (pose === "sleep") {
    return {
      src: stage === "adult" ? "/sprites/adult-sleep/sheet.png" : "/sprites/baby-sleep/sheet.png",
      fps: 2,
    };
  }
  if (pose === "happy" || pose === "eat") {
    if (stage === "adult") return { src: "/sprites/adult-idle/sheet.png", fps: 6 };
    return { src: "/sprites/baby-happy/sheet.png", fps: 6 };
  }
  if (stage === "baby") return { src: "/sprites/baby-idle/sheet.png", fps: 4 };
  if (stage === "child") return { src: "/sprites/child-idle/sheet.png", fps: 4 };
  return { src: "/sprites/adult-idle/sheet.png", fps: 4 };
}

function sizeFor(stage: Stage) {
  if (stage === "egg") return "w-[42vw] max-w-[220px] aspect-square";
  if (stage === "baby") return "w-[48vw] max-w-[260px] aspect-square";
  if (stage === "child") return "w-[52vw] max-w-[280px] aspect-square";
  return "w-[56vw] max-w-[300px] aspect-square";
}

export function PetView() {
  const state = useGame((s) => s.state);
  const pose = useGame((s) => s.pose);
  const petPet = useGame((s) => s.petPet);
  const sheet = sheetFor(state.stage, pose);
  const sad = !state.sleeping && state.mood < 32;

  return (
    <div className="relative flex flex-1 items-end justify-center pb-[8%]">
      <button
        type="button"
        className={cn(
          "relative touch-manipulation select-none rounded-full outline-none",
          "transition-transform duration-150 ease-out active:scale-[0.96]",
          sizeFor(state.stage),
          pose === "happy" && "animate-[pet-bounce_0.6s_var(--ease-pop)]",
          state.sleeping && "opacity-95",
        )}
        onClick={() => {
          if (state.stage === "egg") return;
          sfx.pet();
          petPet();
        }}
        aria-label={state.stage === "egg" ? "たまご" : `${state.name}をなでる`}
      >
        <SpriteSheet
          src={sheet.src}
          fps={sheet.fps}
          alt={state.name}
          className={cn(
            "h-full w-full drop-shadow-[0_18px_18px_rgb(74_52_44_/_0.18)]",
            sad && "brightness-[0.92] saturate-[0.85]",
          )}
        />
        {pose === "eat" ? (
          <img
            src="/sprites/food/f1.png"
            alt=""
            className="pointer-events-none absolute -right-[6%] bottom-[18%] w-[28%] animate-[food-nibble_0.4s_ease-out]"
          />
        ) : null}
      </button>
      <Hearts />
      <style>{`
        @keyframes pet-bounce {
          0% { transform: translateY(0) scale(1, 1); }
          35% { transform: translateY(-10px) scale(0.96, 1.06); }
          70% { transform: translateY(2px) scale(1.04, 0.96); }
          100% { transform: translateY(0) scale(1, 1); }
        }
        @keyframes food-nibble {
          from { opacity: 0; transform: translateY(8px) scale(0.8); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
      `}</style>
    </div>
  );
}
