import { useState } from "react";
import { Button } from "@/components/ui/button";
import { SpriteSheet } from "./SpriteSheet";
import { sfx, unlockAudio } from "@/lib/game/audio";
import { useGame } from "@/lib/game/store";

export function HatchScreen() {
  const name = useGame((s) => s.state.name);
  const hatchPet = useGame((s) => s.hatchPet);
  const [taps, setTaps] = useState(0);
  const ready = taps >= 5;

  return (
    <div className="relative flex h-dvh flex-col overflow-hidden bg-bg">
      <img src="/bg/room-day.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-bg/25" />
      <div className="relative flex min-h-0 flex-1 flex-col items-center justify-between px-6 py-[max(1.5rem,env(safe-area-inset-top))] pb-[max(1.5rem,env(safe-area-inset-bottom))]">
        <div className="text-center">
          <p className="text-sm text-muted">あたたかい へや</p>
          <h1 className="mt-1 font-display text-2xl font-medium text-ink">{name}の たまご</h1>
        </div>
        <button
          type="button"
          className="relative touch-manipulation"
          onClick={() => {
            unlockAudio();
            sfx.tap();
            setTaps((n) => Math.min(6, n + 1));
          }}
          aria-label="たまごをつつく"
        >
          <SpriteSheet
            src="/sprites/egg/sheet.png"
            fps={ready ? 6 : 3}
            playing
            alt="たまご"
            className="h-[58vw] max-h-[320px] w-[58vw] max-w-[320px] drop-shadow-[0_18px_20px_rgb(74_52_44_/_0.22)]"
          />
        </button>
        <div className="w-full max-w-sm text-center">
          <p className="mb-4 text-sm text-ink/80">
            {ready ? "なかから あたたかい 気配がする" : "画面を タップして つつこう"}
          </p>
          <div className="mb-4 flex justify-center gap-1.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <span
                key={i}
                className={`h-1.5 w-7 rounded-pill ${i < taps ? "bg-coral" : "bg-ink/15"}`}
              />
            ))}
          </div>
          <Button
            size="xl"
            className="w-full"
            disabled={!ready}
            onClick={() => {
              unlockAudio();
              sfx.hatch();
              hatchPet();
            }}
          >
            うまれる
          </Button>
        </div>
      </div>
    </div>
  );
}
