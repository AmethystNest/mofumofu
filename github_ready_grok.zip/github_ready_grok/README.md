# Grok Workspace — GitHub source export

This repository was reconstructed from `grok_workspace_COPY_PASTE.txt`.

## Important

The source bundle explicitly says generated/vendor/build/image assets were excluded. Therefore this export preserves the supplied source tree, but it is **not guaranteed to build or render identically by itself** until the excluded assets/support files are restored.

Known referenced assets include paths under `public` such as `/sprites/...` and `/bg/...`. The supplied `package.json` also references scripts under `scripts/`, while those files are not present in this source bundle.

## What is preserved

- Original file paths from every `FILE:` section
- Original code/content, without refactoring
- Added only this README and a `.gitignore`

## Single-file copy/paste version

See `COPY_PASTE_ALL.md` if you want to open one file and copy the whole project source without navigating folders.
